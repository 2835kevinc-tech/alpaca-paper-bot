# Investing Strategy

## Style
- Approach (long-term compounding / swing / narrative-driven / income / hybrid): Hybrid swing/momentum. Match the hold time to the stock's rhythm: if it swings high-to-low every day, same-day; if it trends up and down over several days, hold a similar number of days; weeks/months if the trend is that slow.
- Typical holding period: Varies (same day to weeks). Because he is at work during market hours, flagged picks should favor setups that can be held for days.

## Position Rules
- Position sizing rule (e.g. max % per position): Alpaca: normal 10-15% per position; up to 30% only for a high-conviction "temporary dip" buy, only ONE such 30% position at a time; scale in (about 1/3 first, add only if it stabilizes). Webull: tiny share sizes, fractional where possible.
- Max positions held at once: Webull 3. Alpaca 8 (assistant recommendation), keep at least 10% cash.
- When I add to a position: Only when a drop is caused by clearly temporary news and the stock shows signs of stabilizing. NOT just because it is down (no averaging down on hope).
- When I trim or exit: Stop losses below. Sell after an abnormal spike levels off and before a downward trend starts. Trailing stop once a trade is +15%: sell if it falls 7% from its peak (10% for very volatile stocks/crypto).

## Focus
- Sectors / assets I focus on: Stocks and crypto, with focus on daily high-volatility movers, breakouts, and largest swings; currently stocks at $20 and under on Webull (changeable on request). Everything allowed (options, margin, penny stocks, crypto) unless it costs a subscription.
- What I deliberately avoid: Nothing off-limits. Assistant suggests caution on options/margin until the paper bot shows a track record.
- Edge I believe I have (be honest): Reads trend, highs/lows, and news before entering; decent at finding low entries. Weakness so far: exits and sizing (net about +$1).

## Discipline
- Profit-taking rule: Trailing stop (7%, or 10% for volatile names) once a position is up 15%.
- Stop-loss / drawdown rule: Price-per-share stop 15% for stocks under $100 with a max loss of about $30 per trade; 20% for $100-$1,000 stocks; 10% for $1,000+ stocks when there is no news and no sign of leveling off. Assistant recommendation: cap loss per trade at about 2% of the account and size stops to each stock's normal daily movement (ATR).
- Mistakes I've made before that Claude should call out if I repeat them: (1) averaging down on a loser; (2) tiny same-day exits for a dollar; (3) chasing a stock after it has already spiked. Also: holding a loser past the stop (example: PMAX, down ~32% vs a 15% rule).

## Learning rule (Alpaca bot)
- Every trade is written to a journal: why it bought, why it sold, what went wrong if it lost. Before every new trade the bot reads the journal and skips setups that already burned it. Review every weekend.

## v2 changes (2026-10-03, user-approved)
- Universe widened from "stocks $20 and under" to all US stocks that pass a quality filter (price >= $1, volume >= 500k/day, spread <= 2%). Affordability on the $38 Webull account is handled by max-dollar sizing and fractional shares.
- Added: market-mood check (skip dips if SPY down > 1.5%), earnings blackout (3 days), no-chasing (>10% up today), graduation scorecard vs SPY.
- Crypto added to the Alpaca PAPER bot only: 7% size, 25% total cap, 12% stop, 10% trail. Webull crypto account stays off for now.
