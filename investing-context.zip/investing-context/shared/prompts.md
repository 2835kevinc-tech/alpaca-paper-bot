# Research Prompt Library

## 1 — The Snapshot
Give me a full snapshot of $TICKER: current price and how it's moved this month, valuation 
vs its 5-year averages, last quarter's results vs analyst estimates, current analyst price 
targets, and any red flags in recent filings.

## 2 — The Filings Digest
Pull the latest earnings report and recent SEC filings for $TICKER. Summarise what 
actually changed this quarter — revenue drivers, margins, guidance — and flag anything 
management seems to be downplaying or burying.

## 3 — The Head-to-Head
Compare $A vs $B on valuation, revenue growth, margins, debt, and analyst sentiment. Build 
me a comparison table, then tell me which one the data favors and make the strongest case 
for it.

## 4 — The Finder
Screen the market for small caps under $2B with revenue growth above 25%, positive free 
cash flow, and expanding margins. Cross-check against analyst coverage and flag the 3–5 
trading furthest below price targets — give me the bull case and the biggest risk for 
each.
(Note: starting points for your own diligence, not picks — small caps are illiquid.)

## 5 — The Morning Loop (run inside your Stock Research Project — it needs your profile, 
portfolio, and watchlist as context)
Run my morning loop: overnight moves in the major indexes, pre-market gainers and losers, 
today's earnings and economic calendar, latest news on my watchlist — then check it all 
against my portfolio and investor profile: flag anything that hits my holdings, upcoming 
earnings dates I need to watch, and the one thing that most needs my attention today.

## Trust rule (applies to every prompt)
If Claude gives numbers without calling the FMP connector, they may be from memory. Ask: 
"Cite where each figure came from." If it can't, don't trust it.
