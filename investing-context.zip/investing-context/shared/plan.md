# Trading Bot Master Plan (plain-English version)

Honest ground rules (read these first)
- No bot or trader wins every trade. The goal is: lose small, win bigger, and never get wiped out.
- Webull ($38 real money): the bot ONLY researches and sends you flags. You press the buttons. It cannot buy, sell, or move money.
- Alpaca ($5,000 FAKE money): the bot trades by itself, inside written safety rules.
- The two bots are two separate projects. They never share keys, money, or permissions.

---------------------------------------------------------------
## STAGE 0 - Get the foundation ready (this weekend)
What: Put your profile, strategy, portfolio, watchlist, and prompts in one folder. DONE (the 5 files).
Why: Think of it like a playbook. The bot reads it every time so you never have to re-explain.
Fix first:
1. Decide the real rules once and write them down (done in strategy.md).
2. Pick ONE position-size rule and ONE stop rule so they don't fight each other.

## STAGE 1 - The "eyes": market data (free first)
What: The bot needs prices, news, and earnings dates.
Options, cheapest first:
- Webull connector (already connected here): prices, 52-week highs/lows, gainers/losers, most active, earnings calendar, analyst targets. Read-only use.
- FMP connector (appears connected here): quotes, news, technical indicators, filings. Check your plan before relying on it - if it costs money, you decide.
- Alpaca market data (free tier with a paper account): prices and news for stocks and crypto.
Why: Bad data = bad trades. Every number must say where it came from.

## STAGE 2 - Project A: WEBULL "ALERT BOT" (real money, flag only)
Jobs:
1. Scan stocks under $20 that are moving a lot, breaking out, or had a big swing (you already have a weekday scheduled scan for this).
2. For each candidate, check: trend, highs/lows, news, volume, earnings date coming up.
3. Send you a flag: "Ticker, why, entry zone, stop price, sell target, max shares for your $38."
4. Watch your 2 holdings (PMAX, AAPL) and flag when a stop is hit.
Hard rules:
- Max 3 positions. Never use Webull's order tools. No funding or transfers.
- Because you are at work during market hours, flags are timed for ~5:00 AM (pre-market view), your 3:30 PM break, and weekend review.
- Cash account: sell money takes 1 business day to settle. Don't count it as spendable the same day.
What you need connected: Webull connector (done), a way to notify you (email via Gmail connector, or a push notification), scheduled task.

## STAGE 3 - Project B: ALPACA "PAPER BOT" (fake $5,000, fully automated)
Parts of the bot (like a car):
- Eyes: data feed (Stage 1).
- Brain: scanner + rules + the journal. Finds setups that match your style (temporary-dip, steady trend, spike-then-level-off).
- Hands: sends orders to Alpaca's paper account through its API.
- Seatbelt: risk manager that blocks any order that breaks a rule.
- Diary: logs every trade and every reason.
What you need:
1. A free Alpaca account, switch to Paper Trading, and make API keys (a key ID and a secret).
2. A place to run it: a small Python program on a schedule (cloud scheduler or a cheap/free host). Claude cannot trade by itself without a program running somewhere.
3. Keys stored as secrets (never typed into a chat or saved in a file you share).
Risk Manager rules (the seatbelt):
- Normal position 10-15% of the account; max 30% only for a high-confidence dip buy, only one at a time.
- Max 8 positions, always keep 10%+ cash.
- Stop-loss on every trade the moment it is bought (15% under $100, 20% for $100-$1,000, 10% above $1,000 when there is no news) AND never risk more than ~2% of the account on one trade.
- Trailing stop after +15% (7%, or 10% for jumpy stocks/crypto).
- No averaging down on a loser. Only add if the stock stabilizes and the reason is still true.
- Pause-and-review at -30% total (bot stops, shows what went wrong).

## STAGE 4 - The "memory": journal that learns
What: A file (journal.csv) with one row per trade: date, ticker, why bought, price, stop, why sold, result, lesson.
How it learns: Before each new trade the bot searches the journal for similar setups. If similar trades lost, it skips or cuts the size. Every weekend it writes a short "what worked / what didn't" note.
Why: This is the honest version of "learning from mistakes like a human."

## STAGE 5 - Testing before trust
1. Backtest: run the rules on past data first (cheap and fast).
2. Paper trade for at least 4-8 weeks on Alpaca.
3. Judge it by: win rate, average win vs average loss, biggest drop, and whether it followed its own rules. Not just total profit.
Paper-money warning: paper fills are friendlier than real life (no slippage, instant fills). Real results will be a bit worse.

## STAGE 6 - Graduation rule (when real money grows)
Only add money to Webull ($38 -> $75 -> $100) after Alpaca shows:
- 8+ weeks, positive after losses, biggest drop under 20%, no rule breaks.
Even then, the Webull bot keeps flag-only authority unless YOU change that on purpose.
Set the stop at total dollars you've put in, not just the current balance.

## STAGE 7 - Daily/weekly routine
- 5:00 AM: Morning Loop flag message.
- 3:30 PM: quick check-in flag.
- Weekend: review journal, update watchlist, adjust one rule at most.
- Every quarter: re-read the profile and strategy.

---------------------------------------------------------------
## MISTAKES CHECK

Possible mistakes on YOUR side
1. The $20,000 goal (4x in 6 months) pushes any bot toward huge, risky bets. Better target: 5-15% with limited drops.
2. "Buy a lot on a dip" + 30% sizing + "put more in when it drops" = how small accounts die. Fix: scale in (1/3 at a time), one big position max.
3. PMAX is down ~32% while your own stop is 15%. Holding past your stop is the habit to break.
4. Rules that overlap ($30 cap vs 15% stop). Use one: 15% stop + ~2% account risk.
5. Day trading while at work. Not possible live; use setups that last days.
6. Your $38 is mostly a learning cost; fees/spreads on penny stocks can eat a bigger share than on big stocks.

Possible mistakes on MY side
1. I can't promise no losses or "no mistakes." I can build rules that limit them.
2. I told you the Alpaca bot "learns like a human." It really learns from its own journal and rules - it does not have intuition.
3. I mentioned FMP as a possible cost; it looks connected already. Check what plan you are on before assuming.
4. My numbers must come from tools. If I quote one without a source, call it out.
5. An automated bot can fail quietly (key expires, data feed stops). Needs a daily "heartbeat" check.

## KEEPING THE PROJECTS COMPLETELY SEPARATE
1. Two folders: webull-alerts/ and alpaca-paper/. Each has its own profile, strategy, journal, and keys.
2. Two separate Claude Projects (or at least two separate chats) so memory and instructions don't mix.
3. Different API keys and no shared accounts. Never put Webull credentials near the Alpaca code.
4. Webull project: do NOT enable order-placing tools. Read-only data only. Alerts go out by email/push.
5. Alpaca project: paper keys only. Add a switch in the code so it refuses to run if the base URL is not the paper URL.
6. One-way idea sharing: Alpaca's weekly "lessons" can be COPIED to Webull by you. Webull never sends anything back.
7. Kill switches: Alpaca pause at -30%; Webull alerts stop if you say "pause".

## SUMMARY
Stage 0 playbook -> Stage 1 data -> Stage 2 Webull alert bot (real, flag only, 3 positions) -> Stage 3 Alpaca paper bot (automated, with seatbelt) -> Stage 4 journal-based learning -> Stage 5 backtest and 4-8 weeks of paper -> Stage 6 earn the right to add real money -> Stage 7 routine. Two projects, two sets of keys, never mixed.
