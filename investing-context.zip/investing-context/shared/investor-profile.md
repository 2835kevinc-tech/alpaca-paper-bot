# Investor Profile

## Background
- Experience level: Beginner with some real-money trading (Webull, small amounts)
- Years investing: TODO
- Relevant background (finance, tech, none): No finance/tech background; works production at a chicken plant (5:30am-2:40pm); past forklift/plumbing/handyman experience
- Past trading approach: looked at trend, how long it had been up/down, open high/low, recent highs/lows, and news; bought at relative lows; mostly sold same day, some held for days. Net result about +$1 total.

## Goals
- Primary goal (wealth building / income / speculation / learning): Extra income, and learning (Webull is a trial run; Alpaca paper bot proves the strategy first)
- Time horizon: 6-month evaluation of the Alpaca paper bot
- Target outcome: User's stated dream is $5,000 -> $20,000 in 6 months on Alpaca paper (300%). Corrected working target: 5-15% over 6 months with controlled losses; judge success by win/loss size and rule-following, not total profit alone.

## Risk
- Risk tolerance (with a concrete example of behaviour in a drawdown): In a big drawdown (e.g. $38 -> $26) he would put MORE money in rather than sell (averaging down) - flagged as a risk habit.
- Max acceptable position drawdown before acting: 15% price drop (under $100/share trades, max ~$30 loss); 20% for $100-$1,000 stocks; 10% for $1,000+ stocks when no news and no sign of leveling off. Assistant recommended: ATR-based stops and max ~2% of account risk per trade.
- Portfolio size bracket (small / mid / large): Small. Webull real money: $38 now, planned to grow to $75-$100 only if the Alpaca bot proves effective. Alpaca paper: $5,000 fake money.
- Webull account wipe-out tolerance: would stop if the whole $38 were lost; plans to keep adding money, so assistant suggests the stop be based on total dollars put in.
- Alpaca paper: can lose all of it (it is practice money). Assistant suggests a pause-and-review at -30%.

## Constraints
- Time available for research per week: Weekdays roughly 3:30pm-8:30pm; weekends free but starting a weekend side gig (3-5 hrs/day). At work during market hours (9:30-4:00 ET).
- Tax situation notes (optional): TODO
- Anything off-limits: Nothing (options, margin, penny stocks, crypto all fair game) unless it requires a paid subscription - user decides case by case.

## Authority / Boundaries
- Webull (real money): Claude may research and flag/notify picks only. Claude may NOT place orders, sell, or transfer/fund money. Max 3 positions held.
- Alpaca (paper money): fully automated, full authority inside the written risk rules.
