import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "bot"))
from risk import *
import config

def test_stops():
    assert stop_pct_for_price(20) == 0.15
    assert stop_pct_for_price(500) == 0.20
    assert stop_pct_for_price(1500, no_news=True) == 0.10
    assert stop_pct_for_price(20, atr_pct=0.25) == 0.25

def test_two_percent_cap():
    # $20 stock, 15% stop: 2% of 5000 = $100 risk -> $666 position cap, 15% size = $750
    s = shares_to_buy(20, 0.15, 0, 5000)
    assert abs(s * 20 - 666.67) < 1

def test_blocks():
    assert shares_to_buy(20, 0.15, 8, 5000) == 0
    assert shares_to_buy(20, 0.15, 0, 400) == 0   # cash under 10% floor

def test_pause():
    assert should_pause(3400) and not should_pause(3600)

def test_guard():
    os.environ["ALPACA_BASE_URL"] = "https://api.alpaca.markets"
    try:
        config.get_base_url(); assert False
    except SystemExit:
        pass
    del os.environ["ALPACA_BASE_URL"]


from filters import *
from scorecard import scorecard

def test_quality():
    assert passes_quality(5.0, 1_000_000, 4.99, 5.01)[0]
    assert not passes_quality(0.5, 5_000_000, 0.49, 0.51)[0]
    assert not passes_quality(5.0, 100_000, 4.99, 5.01)[0]
    assert not passes_quality(5.0, 1_000_000, 4.50, 5.00)[0]

def test_mood_earnings_chase():
    assert market_mood_ok(-0.005) and not market_mood_ok(-0.02)
    assert earnings_ok(10) and not earnings_ok(2) and earnings_ok(None)
    assert not_chasing(0.05) and not not_chasing(0.30)

def test_crypto_cap():
    assert abs(crypto_dollars(5000, 0) - 350) < 0.01
    assert crypto_dollars(5000, 1200) == 50.0   # cap 1250, 50 room left
    assert crypto_dollars(5000, 1300) == 0.0

def test_scorecard():
    ok = scorecard(5000, 5400, 100, 102, [0.10, -0.04, 0.08], 0.08, 0)
    assert ok["earns_more_real_money"]
    bad = scorecard(5000, 5100, 100, 105, [0.10, -0.04], 0.08, 0)
    assert not bad["earns_more_real_money"]
