"""Settings for the Alpaca PAPER bot. Keys come from environment variables only."""
import os

PAPER_BASE_URL = "https://paper-api.alpaca.markets"
DATA_BASE_URL = "https://data.alpaca.markets"

# The Alpaca paper account usually starts with ~$100,000 of fake money.
# The bot pretends it only has this much, so sizing matches the $5,000 plan.
VIRTUAL_CAPITAL = 5000.0

# Risk rules (mirror risk-rules.md)
NORMAL_POSITION_PCT = 0.15
MAX_DIP_POSITION_PCT = 0.30
MAX_POSITIONS = 8
MIN_CASH_PCT = 0.10
MAX_RISK_PER_TRADE_PCT = 0.02
PAUSE_DRAWDOWN_PCT = 0.30


def get_keys():
    key = os.environ.get("ALPACA_KEY_ID")
    secret = os.environ.get("ALPACA_SECRET")
    if not key or not secret:
        raise SystemExit("Missing ALPACA_KEY_ID / ALPACA_SECRET environment variables.")
    return key, secret


def get_base_url():
    url = os.environ.get("ALPACA_BASE_URL", PAPER_BASE_URL).rstrip("/")
    if url != PAPER_BASE_URL:
        raise SystemExit(f"REFUSING TO RUN: base URL must be the PAPER url, got {url}")
    return url


# --- v2 additions: quality filter, market mood, earnings, crypto ---
MIN_PRICE = 1.00                 # no sub-$1 stocks
MIN_AVG_DAILY_VOLUME = 500_000   # shares/day
MAX_SPREAD_PCT = 0.02            # bid/ask gap must be under 2% of price
MARKET_MOOD_MAX_DROP_PCT = -0.015  # skip dip buys if S&P 500 (SPY) is down more than 1.5% today
EARNINGS_BLACKOUT_DAYS = 3       # skip stocks reporting within 3 days
MAX_SPIKE_TODAY_PCT = 0.10       # do not chase a stock already up >10% today

# Crypto (paper only first)
MAX_CRYPTO_PCT_OF_ACCOUNT = 0.25
CRYPTO_NORMAL_POSITION_PCT = 0.07   # smaller than stocks (15%)
CRYPTO_STOP_PCT = 0.12              # wider stop (12%)
CRYPTO_TRAIL_PCT = 0.10             # trailing stop 10% once up 15%
