"""Graduation scorecard: did the bot beat simply holding the S&P 500 (SPY)?"""

def scorecard(start_equity, end_equity, spy_start, spy_end, trades_pnl_pct, max_drawdown_pct, rule_breaks):
    bot_ret = end_equity / start_equity - 1
    spy_ret = spy_end / spy_start - 1
    wins = [t for t in trades_pnl_pct if t > 0]
    losses = [t for t in trades_pnl_pct if t <= 0]
    avg_win = sum(wins) / len(wins) if wins else 0.0
    avg_loss = sum(losses) / len(losses) if losses else 0.0
    passed = (bot_ret > spy_ret and bot_ret > 0 and max_drawdown_pct < 0.20 and rule_breaks == 0
              and avg_win > abs(avg_loss))
    return {"bot_return": bot_ret, "spy_return": spy_ret, "avg_win": avg_win, "avg_loss": avg_loss,
            "win_rate": len(wins) / len(trades_pnl_pct) if trades_pnl_pct else 0.0,
            "max_drawdown": max_drawdown_pct, "rule_breaks": rule_breaks, "earns_more_real_money": passed}
