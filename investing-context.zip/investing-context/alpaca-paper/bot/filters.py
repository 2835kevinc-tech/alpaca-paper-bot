"""Quality filters: decide whether a stock/coin is even allowed to be considered. Pure logic."""
from config import *


def passes_quality(price, avg_volume, bid, ask):
    """Returns (ok, reason)."""
    if price < MIN_PRICE:
        return False, "price under $1"
    if avg_volume < MIN_AVG_DAILY_VOLUME:
        return False, "volume too thin"
    if bid <= 0 or ask <= 0 or (ask - bid) / price > MAX_SPREAD_PCT:
        return False, "bid/ask gap too wide"
    return True, "ok"


def market_mood_ok(spy_change_today):
    """spy_change_today as a fraction, e.g. -0.02 for -2%."""
    return spy_change_today > MARKET_MOOD_MAX_DROP_PCT


def earnings_ok(days_until_earnings):
    """days_until_earnings may be None (unknown earnings date -> allowed but flagged)."""
    if days_until_earnings is None:
        return True
    return days_until_earnings > EARNINGS_BLACKOUT_DAYS


def not_chasing(change_today):
    return change_today <= MAX_SPIKE_TODAY_PCT


def crypto_dollars(equity_virtual, current_crypto_dollars):
    """How many dollars of crypto may be bought now (respects 7% size and 25% total cap)."""
    room = equity_virtual * MAX_CRYPTO_PCT_OF_ACCOUNT - current_crypto_dollars
    return max(0.0, min(equity_virtual * CRYPTO_NORMAL_POSITION_PCT, room))
